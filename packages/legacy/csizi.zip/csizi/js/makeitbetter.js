function del() {
  $elem = document.getElementById('page');
  $elem.value = "";
}